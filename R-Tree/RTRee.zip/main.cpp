#include <string>
#include <vector>
#include <iostream>
#include <cstdlib> 
#include <time.h> 
#include <fstream>

#include "RTree.h"

using namespace std;

 void print(const int& command, vector<vector<vector<pair<int, int>>>>& objects_n, string& output) {
	output.resize(0);
	output = command;

	switch (command)
	{
    case 0:// OBJECTS
		output += "|" + to_string(objects_n[0].size());
		for (auto& polygon : objects_n[0]) {
			output += "|" + to_string(polygon.size());
      
			for (auto& point : polygon) {
				output += "|" + to_string(point.first) + "|" + to_string(point.second);
			}
		}
		break;

	case 1: //MBRS:
    cout<<" number of (objects) :"<< to_string(objects_n.size())<<endl;
		output += "|" + to_string(objects_n.size());
		for (auto& objects : objects_n) {
			output += "|" + to_string(objects.size());
      cout<<" number of polygons :"<< to_string(objects.size())<<endl;
			for (auto& polygon : objects) {
				output += "|" + to_string(polygon.size());
        cout<<" number of points :"<< to_string(polygon.size())<<endl;
				for (auto& point : polygon) {
					output += "|" + to_string(point.first) + "|" + to_string(point.second);
          cout<<"   point:"<< to_string(point.first) << " | " << to_string(point.second)<<endl;
          
				}
			}
      cout<<endl<<"--------------------"<< endl; 
		}
		break;
	default:
		output += "|0";
		break;
	}

	output += "|END";
  //cout<<output;
}

void print_pair(vector<pair<int, int>> output){
  for(auto &x:output)
  {
    cout<<" ( "<<x.first<<" , "<<x.second<< " ) ";
  }
  }

int main()
{
	vector<vector<pair<int, int>>> vpoints;
  
  // Conjunto de 2 puntos
  srand(time(0));
  const int numEntries= 1000;

  int cant1= numEntries/5*2;

  float coord1[cant1];
  for(int i= 0; i< sizeof(coord1)/sizeof(float); i++){
    coord1[i]= rand()%1000;
  }
  
  vector<pair<int, int>> points;
  for(int i =0;i<cant1;i+=2){
    pair<int,int> A;
    A.first = coord1[i];
    A.second = coord1[i+1];
    points.push_back(A);          
  }
  for (unsigned int i =0;i<cant1/2; i+=2){       
    vector<pair<int, int>>  sub1(&points[i],&points[i+2]);
    vpoints.push_back(sub1);
  }
  
  // Conjunto de 3 puntos
  int cant2= numEntries/5*3;
  float coord2[cant2];
  for(int i= 0; i< sizeof(coord2)/sizeof(float); i++){
    coord2[i]= rand()%1000;
  }
  vector<pair<int, int>> points2;
  for(int i =0;i<cant2;i+=2){
    pair<int,int> A;
    A.first = coord2[i];
    A.second = coord2[i+1];
    points2.push_back(A);          
  }
  for (unsigned int i =0;i<cant2/2; i+=3){  
    vector<pair<int, int>>  sub1(&points2[i],&points2[i+3]);
    vpoints.push_back(sub1);
  }

  RTree rtree;
	string output;
	vector<vector<pair<int, int>>> objects;

  vector<vector<vector<pair<int, int>>>> objects_n;

  for(auto &x:vpoints)
    {
      cout<<"Inserting "<< x.size()<< ": ";
      print_pair(x);
      Rect rect = rtree.MBR(x);
      rtree.Insert(rect.m_min, rect.m_max, x);
      cout<< endl;
    }  
  rtree.getMBRs(objects_n);
  print(1, objects_n, output);

  // Funcion Search
  Rect rectFind(0,0,1000,1000);
  vector<Rect> rects= rtree.Search(rectFind);
  cout<<"Search: "<<endl;
  vector<int> data;
  for(int i= 0; i< rects.size(); i++){
    int x_min= rects[i].m_min[0];
    int x_max= rects[i].m_max[0];
    int y_min= rects[i].m_min[1];
    int y_max= rects[i].m_max[1];
    data.push_back(x_min);
    data.push_back(y_min);
    data.push_back(x_max);
    data.push_back(y_max);
    cout<<"("<<x_min<<","<<y_min<<")"<<endl;
    cout<<"("<<x_max<<","<<y_max<<")"<<endl;
    cout<<endl;
  }
  ofstream archivo("coordenadas.txt");
  if(archivo.is_open()){
    for(int i= 0; i< data.size(); i+= 4){
      archivo << data[i] << " ";
      archivo << data[i+1] << " ";
      archivo << data[i+2] << " ";
      archivo << data[i+3] << endl;
    }
    archivo.close();
  }
  else{
    cerr<<"No se pudo abrir el archivo"<<endl;
  }
	return 0;
}
