import matplotlib.pyplot as plt

# Leer las coordenadas desde un archivo (cambiar a tu método de lectura específico)
with open("/Users/abimaelruiztrelles/Documents/EDA/Lab3/output/coordenadas.txt", "r") as file:
    lines = file.readlines()

# Inicializar una figura de matplotlib
fig, ax = plt.subplots()

# Procesar las coordenadas y dibujar los rectángulos
for line in lines:
    x_min, y_min, x_max, y_max = map(float, line.split())  # Suponiendo que los datos están en el formato "x_min y_min x_max y_max"
    width = x_max - x_min
    height = y_max - y_min

    # Dibujar un rectángulo con esquina inferior izquierda (x_min, y_min)
    ax.add_patch(plt.Rectangle((x_min, y_min), width, height, fill=False, color= "green"))

# Configurar límites de la figura
ax.set_xlim(0,1000)
ax.set_ylim(0,1000)

# Mostrar la figura
plt.show()
