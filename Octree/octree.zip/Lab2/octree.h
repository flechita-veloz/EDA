#include <iostream>
#include <vector>
#include <cmath>
using namespace std;


/*
      4-------5
     /|      /|
    / |     / |
   /  7----/  6
  0-------1  /
  | /     | /
  |/      |/
  3-------2
  
  0-> limSup= topLeftFront
  6-> limInf= bottomRightBack
*/

#define MIN -1e9
// Struct de un Punto
struct Point {
    double x;
    double y;
    double z;
    Point()
        : x(MIN), y(MIN), z(MIN)
    {
    }

    Point(double a, double b, double c)
        : x(a), y(b), z(c)
    {
    }
};

// Clase Octree 
class Octree {
public:
    // if point == NULL, es un nodo interno
    // if point == (MIN, MIN, MIN), es un nodo vacio
    Point* point;
    double sideCube;

    // representa los limites del cubo 0 y 6
    Point *topLeftFront, *bottomRightBack;
    vector<Octree*> children;

    // Constructor 
    Octree(Point* limSup, Point* limInf)
    {
        // constructor con limites definidos
        int x1= limSup->x, y1= limSup->y, z1= limSup->z;
        int x2= limInf->x, y2= limInf->y, z2= limInf->z;
        if (x2 < x1
            || y2 < y1
            || z1 < z2) {
            cout << "Puntos limite no validos" << endl;
            return;
        }
        point = new Point();
        topLeftFront
            = limSup;
        bottomRightBack
            = limInf;
        sideCube= abs(topLeftFront->x - bottomRightBack->x);
    }

    void splitOctree(){
        children.assign(8, nullptr);
        double midx = (topLeftFront->x
                    + bottomRightBack->x)
                   / 2;
        double midy = (topLeftFront->y
                    + bottomRightBack->y)
                   / 2;
        double midz = (topLeftFront->z
                    + bottomRightBack->z)
                   / 2;
        // limites con respecto a topLeftFront: arista 0
        children[0] = new Octree(new Point(topLeftFront->x,topLeftFront->y,topLeftFront->z), 
                    new Point(midx,midy,midz));
        children[1] = new Octree(new Point(midx,topLeftFront->y,topLeftFront->z), 
                    new Point(topLeftFront->x+sideCube,midy,midz));
        children[2] = new Octree(new Point(midx,topLeftFront->y,midz), 
                    new Point(topLeftFront->x + sideCube,midy,topLeftFront->z - sideCube));
        children[3] = new Octree(new Point(topLeftFront->x,topLeftFront->y,midz), 
                        new Point(midx,midy,topLeftFront->z - sideCube));
        children[4] = new Octree(new Point(topLeftFront->x,midy,topLeftFront->z), 
                    new Point(midx,topLeftFront->y+sideCube,midz));
        children[5] = new Octree(new Point(midx,midy,topLeftFront->z), 
                    new Point(topLeftFront->x+sideCube,topLeftFront->y+sideCube,midz));
        children[6] = new Octree(new Point(midx,midy,midz), 
                    new Point(topLeftFront->x + sideCube,topLeftFront->y + sideCube,topLeftFront->z - sideCube));
        children[7] = new Octree(new Point(topLeftFront->x,midy,midz), 
                    new Point(midx,topLeftFront->y + sideCube,topLeftFront->z - sideCube));
    }

    // Funcion para insertar un punto
    void insert(Point &punto)
    {
        double x= punto.x, y= punto.y, z= punto.z;
        // If el punto (x,y,z) ya existe
        if (exist(punto)) {
            cout << "Punto ya existente en el arbol" << endl;
            return;
        }
        // si el nodo esta dentro de los limites
        if (x < topLeftFront->x
            || x > bottomRightBack->x
            || y < topLeftFront->y
            || y > bottomRightBack->y
            || z > topLeftFront->z
            || z < bottomRightBack->z) {
            cout << "Punto fuera de limites" << endl;
            return;
        }
        // realizando busqueda binaria
        double midx = (topLeftFront->x
                    + bottomRightBack->x)
                   / 2;
        double midy = (topLeftFront->y
                    + bottomRightBack->y)
                   / 2;
        double midz = (topLeftFront->z
                    + bottomRightBack->z)
                   / 2;

        int pos = -1;

        // decidiendo la posicion
        if (x <= midx) {
            if (y <= midy) {
                if (z <= midz)
                    pos = 3;
                else
                    pos = 0;
            }
            else {
                if (z <= midz)
                    pos = 7;
                else
                    pos = 4;
            }
        }
        else {
            if (y <= midy) {
                if (z <= midz)
                    pos = 2;
                else
                    pos = 1;
            }
            else {
                if (z <= midz)
                    pos = 6;
                else
                    pos = 5;
            }
        }
        // nodo interno
        if (!children.empty() && point == nullptr) {
            children[pos]->insert(punto);
            return;
        }

        // nodo vacio
        else if (point->x == MIN) {
            point->x= x;
            point->y= y;
            point->z= z;
            return;
        }
        else {
            Point _point(point->x,point->y,point->z);
            delete point;
            point = nullptr;
            splitOctree();
            // limites con respecto a topLeftFront: arista 0
            if (pos == 0) {
                children[0] = new Octree(new Point(topLeftFront->x,topLeftFront->y,topLeftFront->z), 
                            new Point(midx,midy,midz));
            }
            else if (pos == 1) {
                children[1] = new Octree(new Point(midx,topLeftFront->y,topLeftFront->z), 
                            new Point(topLeftFront->x+sideCube,midy,midz));
            }
            else if (pos == 2) {
                children[2] = new Octree(new Point(midx,topLeftFront->y,midz), 
                            new Point(topLeftFront->x + sideCube,midy,topLeftFront->z - sideCube));
            }
            else if (pos == 3) {
                children[3] = new Octree(new Point(topLeftFront->x,topLeftFront->y,midz), 
                                new Point(midx,midy,topLeftFront->z - sideCube));
            }
            else if (pos == 4) {
                children[4] = new Octree(new Point(topLeftFront->x,midy,topLeftFront->z), 
                            new Point(midx,topLeftFront->y+sideCube,midz));
            }
            else if (pos == 5) {
                children[5] = new Octree(new Point(midx,midy,topLeftFront->z), 
                            new Point(topLeftFront->x+sideCube,topLeftFront->y+sideCube,midz));
            }
            else if (pos == 6) {
                children[6] = new Octree(new Point(midx,midy,midz), 
                            new Point(topLeftFront->x + sideCube,topLeftFront->y + sideCube,topLeftFront->z - sideCube));
            }
            else if (pos ==  7) {
                children[7] = new Octree(new Point(topLeftFront->x,midy,midz), 
                            new Point(midx,topLeftFront->y + sideCube,topLeftFront->z - sideCube));
            }
            children[pos]->point= new Point(x,y,z);
            insert(_point);
        }
    }

    // Funcion que retorna true si el punto existe
    // (x, y, z) 
    bool exist(Point &punto)
    {
        // verfificar limites
        double x= punto.x, y= punto.y, z= punto.z;
        if (x < topLeftFront->x
            || x > bottomRightBack->x
            || y < topLeftFront->y
            || y > bottomRightBack->y
            || z > topLeftFront->z
            || z < bottomRightBack->z)
            return 0;
        
        //realizando busqueda binaria
        double midx = (topLeftFront->x
                    + bottomRightBack->x)
                / 2;
        double midy = (topLeftFront->y
                    + bottomRightBack->y)
                / 2;
        double midz = (topLeftFront->z
                    + bottomRightBack->z)
                / 2;

        int pos = -1;
        //decidiendo la posicion
        if (x <= midx) {
            if (y <= midy) {
                if (z <= midz)
                    pos = 3;
                else
                    pos = 0;
            }
            else {
                if (z <= midz)
                    pos = 7;
                else
                    pos = 4;
            }
        }
        else {
            if (y <= midy) {
                if (z <= midz)
                    pos = 2;
                else
                    pos = 1;
            }
            else {
                if (z <= midz)
                    pos = 6;
                else
                    pos = 5;
            }
        }

        // nodo interno
        if (point == nullptr) {
            return children[pos]->exist(punto);
        }

        // nodo vacio
        else if (point->x == MIN) {
            return 0;
        }
        else {
            //verificamos el nodo hoja
            if (x == point->x
                && y == point->y
                && z == point->z)
                return 1;
            return 0;
        }
    }
    //funcion para obtener las hojas del arbol
    void getLeaves(Octree* octante, vector<Octree*> &leaves){
        //si es un nodo interno
        if (octante->point == nullptr) {
            for (int i = 0; i <= 7; ++i) {
                getLeaves(octante->children[i],leaves);
            }
        } 
        //si es un nodo hoja con un punto 
        else if (octante->point->x != -MIN) {
            leaves.push_back(octante);
        }
    }

    double distancia(Point& p1, Point& p2){
        double x1= p1.x, y1= p1.y, z1= p1.z;
        double x2= p2.x, y2= p2.y, z2= p2.z;
        return sqrt(pow(x1-x2,2)+pow(y1-y2,2)+pow(z1-z2,2));
    }

    vector<Point>  find_closest(Octree* raiz, Point& p1, double radius){
        vector<Octree*> leaves;
        vector<Point> points_closest;
        getLeaves(raiz,leaves);
        for(int i= 0; i< leaves.size(); i++){
            double x2= leaves[i]->point->x;
            double y2= leaves[i]->point->y;
            double z2= leaves[i]->point->z;
            Point p2(x2,y2,z2);
            if(p1.x== x2 && p1.y== y2 && p1.z== z2) continue;
            if(distancia(p1,p2)<= radius){
                points_closest.push_back(p2);
            }
        }
        return points_closest;
    }
};

