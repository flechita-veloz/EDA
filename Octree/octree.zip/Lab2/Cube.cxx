#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkCellArray.h>
#include <vtkFloatArray.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPointData.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderer.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkSmartPointer.h>
#include <vtkOutlineFilter.h>
#include <vtkConeSource.h>
#include <vtkProperty.h>

//librerias para leer archivos
#include <fstream>
#include <sstream>

#include <array>
#include "octree.h"

using namespace std;
vtkSmartPointer<vtkActor> createCubeActor(const std::array<std::array<double, 3>, 8>& pts) {
    vtkNew<vtkPoints> points;

    // Definir las aristas del cubo
    vtkNew<vtkCellArray> lines;

    // Cara 1
    vtkNew<vtkIdList> face1;
    face1->InsertNextId(0);
    face1->InsertNextId(1);
    face1->InsertNextId(1);
    face1->InsertNextId(2);
    face1->InsertNextId(2);
    face1->InsertNextId(3);
    face1->InsertNextId(3);
    face1->InsertNextId(0);
    lines->InsertNextCell(face1);

    // Cara 2
    vtkNew<vtkIdList> face2;
    face2->InsertNextId(4);
    face2->InsertNextId(5);
    face2->InsertNextId(5);
    face2->InsertNextId(6);
    face2->InsertNextId(6);
    face2->InsertNextId(7);
    face2->InsertNextId(7);
    face2->InsertNextId(4);
    lines->InsertNextCell(face2);

    // Cara 3
    vtkNew<vtkIdList> face3;
    face3->InsertNextId(0);
    face3->InsertNextId(1);
    face3->InsertNextId(1);
    face3->InsertNextId(5);
    face3->InsertNextId(5);
    face3->InsertNextId(4);
    face3->InsertNextId(4);
    face3->InsertNextId(0);
    lines->InsertNextCell(face3);

    // Cara 4
    vtkNew<vtkIdList> face4;
    face4->InsertNextId(1);
    face4->InsertNextId(2);
    face4->InsertNextId(2);
    face4->InsertNextId(6);
    face4->InsertNextId(6);
    face4->InsertNextId(5);
    face4->InsertNextId(5);
    face4->InsertNextId(1);
    lines->InsertNextCell(face4);

    // Cara 5
    vtkNew<vtkIdList> face5;
    face5->InsertNextId(2);
    face5->InsertNextId(3);
    face5->InsertNextId(3);
    face5->InsertNextId(7);
    face5->InsertNextId(7);
    face5->InsertNextId(6);
    face5->InsertNextId(6);
    face5->InsertNextId(2);
    lines->InsertNextCell(face5);

    // Cara 6
    vtkNew<vtkIdList> face6;
    face6->InsertNextId(3);
    face6->InsertNextId(0);
    face6->InsertNextId(0);
    face6->InsertNextId(4);
    face6->InsertNextId(4);
    face6->InsertNextId(7);
    face6->InsertNextId(7);
    face6->InsertNextId(3);
    lines->InsertNextCell(face6);

    for (auto i = 0ul; i < pts.size(); ++i) {
        points->InsertPoint(i, pts[i].data());
    }

    vtkNew<vtkPolyData> cubeOutline;
    cubeOutline->SetPoints(points);
    cubeOutline->SetLines(lines);

    vtkNew<vtkPolyDataMapper> outlineMapper;
    outlineMapper->SetInputData(cubeOutline);

    vtkNew<vtkActor> outlineActor;
    outlineActor->SetMapper(outlineMapper);
    outlineActor->GetProperty()->SetColor(0.0, 1.0, 0.0); // Color verde (R, G, B)

    return outlineActor;                                      
}

void addCube(double x, double y, double z, double l, vector<array<array<double, 3>, 8>> &cubePointsVector){
  array<array<double,3>,8> punto;
  punto[0]= {x,y,z-l}; //{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, ----- {0, 0, 1}, {1, 0, 1}, {1, 1, 1}, {0, 1, 1}
  punto[1]= {x+l,y,z-l};
  punto[2]= {x+l,y+l,z-l};
  punto[3]= {x,y+l,z-l};
  punto[4]= {x,y,z};
  punto[5]= {x+l,y,z};
  punto[6]= {x+l,y+l,z};
  punto[7]= {x,y+l,z};
  cubePointsVector.push_back(punto);
}

//funcion para obtener las hojas del arbol
void getLeaves(Octree* octante, vector<Octree*> &leaves){
    //si es un nodo interno
    if (octante->point == nullptr) {
        for (int i = 0; i <= 7; ++i) {
            getLeaves(octante->children[i],leaves);
        }
    } 
    //si es un nodo hoja con un punto 
    else if (octante->point->x != -MIN) {
        leaves.push_back(octante);
    }
}

vector<vector<double>> getPoints(string location_file){
  vector<vector<double>> puntos;
    // Abre el archivo CSV para lectura
    ifstream archivo(location_file);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo." << endl;
    }

    string linea;
    while (std::getline(archivo, linea)) {
        istringstream ss(linea);
        double x, y, z;

        // Intenta leer tres valores (x, y, z) desde la línea utilizando la coma como delimitador
        if (ss >> x && ss.ignore() && ss >> y && ss.ignore() && ss >> z) {
            // Añade el punto al vector
            puntos.push_back({x, y, z});
        } else {
            cerr << "Error al leer la línea: " << linea << endl;
        }
    }
    archivo.close();
    return puntos;
}

int main(int, char*[]) {
    vtkNew<vtkRenderer> renderer;
    vtkNew<vtkRenderWindow> renWin;
    renWin->AddRenderer(renderer);
    renWin->SetWindowName("Cubes");

    vtkNew<vtkRenderWindowInteractor> iren;
    iren->SetRenderWindow(renWin);

    vtkNew<vtkNamedColors> colors;

    //Octree
    //Point limSup(-600,-600,600), limInf(600,600,-600);
    Point limSup(-200,-200,200), limInf(200,200,-200);
    Octree tree(&limSup, &limInf); //x1,y1,z1,x2,y2,z2

    //Puntos1 del GATO
    string location_points1= "/Users/abimaelruiztrelles/Documents/EDA/Lab2/points1.csv";
    vector<vector<double>> points1= getPoints(location_points1);

    //Puntos2 del DRAGON 
    string location_points2= "/Users/abimaelruiztrelles/Documents/EDA/Lab2/points2.csv";
    vector<vector<double>> points2= getPoints(location_points2);

    //Ingresamos los puntos a nuestro arbol
    for(int i= 0; i< points2.size(); i++){
      Point punto(points2[i][0],points2[i][1],points2[i][2]);
      tree.insert(punto);
    }

    //creamos nuestro vector de hojas
    vector<Octree*> leaves;
    //vector para almacenar los 8 puntos de nuestro cubo
    std::vector<std::array<std::array<double, 3>, 8>> cubePointsVector;
    //obtenemos las hojas
    getLeaves(&tree,leaves);
    // creamos nuestros cubos
    for(int i= 0; i< leaves.size(); i++){
      Point* punto= leaves[i]->topLeftFront;
      double l= leaves[i]->sideCube;
      addCube(punto->x, punto->y, punto->z, l, cubePointsVector);
    }
    
    for (const auto& cubePoints : cubePointsVector) {
        vtkSmartPointer<vtkActor> cubeActor = createCubeActor(cubePoints);
        renderer->AddActor(cubeActor);
    }

    renderer->SetBackground(colors->GetColor3d("Cornsilk").GetData());

    renWin->SetSize(600, 600);

    // interact with data
    renWin->Render();
    iren->Start();

    return EXIT_SUCCESS;
}
