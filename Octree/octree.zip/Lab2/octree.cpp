#include "octree.h"
#include <fstream>
#include <sstream>

using namespace std;
vector<vector<double>> getPoints(string location_file){
  vector<vector<double>> puntos;
    // Abre el archivo CSV para lectura
    ifstream archivo(location_file);

    if (!archivo.is_open()) {
        cerr << "No se pudo abrir el archivo." << endl;
    }

    string linea;
    while (std::getline(archivo, linea)) {
        istringstream ss(linea);
        double x, y, z;

        // Intenta leer tres valores (x, y, z) desde la línea utilizando la coma como delimitador
        if (ss >> x && ss.ignore() && ss >> y && ss.ignore() && ss >> z) {
            // Añade el punto al vector
            puntos.push_back({x, y, z});
        } else {
            cerr << "Error al leer la línea: " << linea << endl;
        }
    }
    archivo.close();
    return puntos;
}

//funcion para obtener las hojas del arbol
void getLeaves(Octree* octante, vector<Octree*> &leaves){
    //si es un nodo interno
    if (octante->point == nullptr) {
        for (int i = 0; i <= 7; ++i) {
            getLeaves(octante->children[i],leaves);
        }
    } 
    //si es un nodo hoja con un punto 
    else if (octante->point->x != -MIN) {
        leaves.push_back(octante);
    }
}

int main()
{
    Point limSup(-600,-600,600), limInf(600,600,-600);
    Octree tree(&limSup, &limInf); //x1,y1,z1,x2,y2,z2
    string location_points1= "/Users/abimaelruiztrelles/Documents/EDA/Lab2/points1.csv";
    vector<vector<double>> points1= getPoints(location_points1);
    for(int i= 0; i< points1.size(); i++){
      Point punto(points1[i][0],points1[i][1],points1[i][2]);
      tree.insert(punto);
    }
    Point punto(95,105,-34);
    if(tree.exist(punto)){
        cout<<"encontrado"<<endl;
    }
    vector<Point> points_closest= tree.find_closest(&tree,punto,600);
    double mx= -1.0;
    double mn= 1e9;
    for(int i= 0; i< points_closest.size(); i++){
        cout<<points_closest[i].x<<endl;
    }cout<<endl;
    return 0;
}